Sources of images:

http://www.famfamfam.com/lab/icons/silk/
http://projects.opengeo.org/geosilk
http://www.iconarchive.com/